@echo off
REM Build WarpLite.exe on Windows (needs Node.js 20+)
call npm install
call npx electron-builder --win portable --x64
echo Done: dist\WarpLite.exe
pause
