const $ = (id) => document.getElementById(id);
let settings, cur = { status: 'off' };
const mbps = (b) => ((b * 8) / 1e6).toFixed(1) + ' Mbps';
const UNLOCK_ON = 'Speed unlock is on: Windows network limits are removed. It cannot go beyond the speed of your internet plan.';
const UNLOCK_OFF = 'Speed unlock is off: Windows network settings are unchanged.';

function render(s) {
  cur = s;
  const k = s.status === 'on' ? 'on' : s.status === 'connecting' ? 'busy' : s.status === 'error' ? 'bad' : 'off';
  $('power').dataset.on = k;
  $('st').dataset.s = k;
  $('st').textContent = s.status === 'on' ? 'ON' : s.status === 'connecting' ? '...' : 'OFF';
  $('sub').textContent = s.status === 'on' ? (s.via === 'dns' ? 'DNS only (1.1.1.1)' : s.via === 'file' ? 'WireGuard tunnel (country file)' : 'WARP tunnel') : s.status === 'connecting' ? 'Connecting' : 'Not connected';
  $('n1').textContent = s.status === 'on' ? (s.via === 'dns' ? 'Connected through DNS only.' : s.via === 'file' ? 'Connected through your country file.' : 'Connected through WARP.') : s.status === 'connecting' ? 'Connecting...' : s.status === 'error' ? 'Could not connect.' : 'Not connected.';
  $('n2').textContent = settings && settings.unlock ? UNLOCK_ON : UNLOCK_OFF;
  const msg = s.error || s.notice || '';
  $('n3').hidden = !msg; $('n3').textContent = msg; $('n3').className = s.error ? 'warn err' : 'warn';
  $('ctry').textContent = s.status === 'on' && s.country ? s.country : '-';
  $('unl').textContent = settings && settings.unlock ? 'ON' : 'OFF';
  $('speed').dataset.on = settings && settings.unlock ? 'on' : 'off';
  if (s.status !== 'on') { $('down').textContent = $('up').textContent = '0.0 Mbps'; }
}
function applySettings(x) { settings = x; $('mode').value = x.mode; $('country').value = x.country; $('country').disabled = x.mode === 'dns'; render(cur); }

(async () => {
  const init = await warp.init();
  init.countries.forEach((c) => { const o = document.createElement('option'); o.value = c.code; o.textContent = c.code === 'auto' ? c.name : `${c.name} (${c.code})`; $('country').append(o); });
  settings = init.settings; applySettings(settings); render(init.state);
  warp.onState(render);
  warp.onSpeed((s) => { $('down').textContent = mbps(s.down); $('up').textContent = mbps(s.up); });
  $('power').onclick = () => warp.toggle();
  $('mode').onchange = async (e) => applySettings(await warp.set({ mode: e.target.value }));
  $('country').onchange = async (e) => applySettings(await warp.set({ country: e.target.value }));
  $('speed').onclick = async () => { $('speed').disabled = true; applySettings(await warp.set({ unlock: !settings.unlock })); $('speed').disabled = false; };
  $('folder').onclick = () => warp.folder();
})();
