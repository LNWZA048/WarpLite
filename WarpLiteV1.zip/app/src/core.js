const crypto = require('crypto');
const CLASH_PORT = 19090;
const COUNTRIES = [
  { code: 'auto', name: 'Automatic (WARP)' },
  { code: 'SG', name: 'Singapore' }, { code: 'JP', name: 'Japan' },
  { code: 'US', name: 'United States' }, { code: 'UK', name: 'United Kingdom' }, { code: 'MY', name: 'Malaysia' },
];
const WARP_IPS = ['162.159.192.1', '162.159.193.1', '162.159.195.1', '188.114.96.1', '188.114.97.1', '188.114.98.1', '188.114.99.1'];
const WARP_TRIES = [...WARP_IPS.map((ip) => [ip, 2408]), ['162.159.192.1', 500], ['162.159.193.1', 500], ['162.159.192.1', 4500], ['162.159.192.1', 1701]];

function genKeys() {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('x25519');
  return {
    priv: privateKey.export({ type: 'pkcs8', format: 'der' }).subarray(-32).toString('base64'),
    pub: publicKey.export({ type: 'spki', format: 'der' }).subarray(-32).toString('base64'),
  };
}
const cidr = (a, n) => (a.includes('/') ? a : `${a}/${n}`);
const hostPort = (s) => { const m = s.trim().match(/^\[(.+)\]:(\d+)$/) || s.trim().match(/^(.+):(\d+)$/); return m ? { host: m[1], port: +m[2] } : null; };

function parseConf(text) {
  const wg = { private_key: '', addresses: [], dnsServer: '1.1.1.1', mtu: 0, peer: null };
  let sec = '', cur = null;
  for (let line of text.split(/\r?\n/)) {
    line = line.replace(/[#;].*$/, '').trim();
    if (!line) continue;
    const h = line.match(/^\[(\w+)\]$/);
    if (h) { sec = h[1].toLowerCase(); cur = null; if (sec === 'peer' && !wg.peer) cur = wg.peer = { allowed_ips: [] }; continue; }
    const i = line.indexOf('='); if (i < 0) continue;
    const k = line.slice(0, i).trim().toLowerCase(), v = line.slice(i + 1).trim();
    if (sec === 'interface') {
      if (k === 'privatekey') wg.private_key = v;
      else if (k === 'address') wg.addresses.push(...v.split(',').map((x) => x.trim()).filter(Boolean).map((x) => cidr(x, x.includes(':') ? 128 : 32)));
      else if (k === 'dns') { const d = v.split(',').map((x) => x.trim()).find((x) => x && !x.includes(':') && /^[\d.]+$/.test(x)); if (d) wg.dnsServer = d; }
      else if (k === 'mtu') wg.mtu = parseInt(v, 10) || 0;
    } else if (sec === 'peer' && cur) {
      if (k === 'publickey') cur.public_key = v;
      else if (k === 'presharedkey') cur.pre_shared_key = v;
      else if (k === 'endpoint') { const hp = hostPort(v); if (hp) { cur.address = hp.host; cur.port = hp.port; } }
      else if (k === 'allowedips') cur.allowed_ips.push(...v.split(',').map((x) => x.trim()).filter(Boolean));
      else if (k === 'persistentkeepalive') cur.keepalive = parseInt(v, 10) || 0;
    }
  }
  if (!wg.private_key) throw new Error('missing PrivateKey');
  if (!wg.addresses.length) throw new Error('missing Address');
  if (!wg.peer || !wg.peer.public_key || !wg.peer.address) throw new Error('missing Peer PublicKey/Endpoint');
  if (!wg.peer.allowed_ips.length) wg.peer.allowed_ips = ['0.0.0.0/0', '::/0'];
  return wg;
}
function warpToWg(acc, ip, port) {
  return {
    private_key: acc.private_key, addresses: [cidr(acc.address4, 32), cidr(acc.address6, 128)], dnsServer: '1.1.1.1', mtu: 0,
    peer: { address: ip, port, public_key: acc.peer_public_key, allowed_ips: ['0.0.0.0/0', '::/0'], reserved: acc.reserved },
  };
}
function buildConfig(wg, unlock) {
  const mtu = wg.mtu || (unlock ? 1380 : 1280);
  const p = { address: wg.peer.address, port: wg.peer.port, public_key: wg.peer.public_key, allowed_ips: wg.peer.allowed_ips };
  if (wg.peer.pre_shared_key) p.pre_shared_key = wg.peer.pre_shared_key;
  if (wg.peer.reserved) p.reserved = wg.peer.reserved;
  if (wg.peer.keepalive) p.persistent_keepalive_interval = wg.peer.keepalive;
  return {
    log: { level: 'info', timestamp: true },
    dns: { servers: [{ type: 'udp', tag: 'tun-dns', server: wg.dnsServer }, { type: 'udp', tag: 'boot', server: '1.1.1.1', detour: 'direct' }], final: 'tun-dns', strategy: 'prefer_ipv4' },
    inbounds: [{ type: 'tun', tag: 'tun-in', address: ['172.19.0.1/30', 'fdfe:dcba:9876::1/126'], auto_route: true, strict_route: true, stack: 'mixed', mtu }],
    endpoints: [{ type: 'wireguard', tag: 'warp', mtu, address: wg.addresses, private_key: wg.private_key, peers: [p] }],
    outbounds: [{ type: 'direct', tag: 'direct' }],
    route: {
      auto_detect_interface: true, final: 'warp', default_domain_resolver: 'boot',
      rules: [{ action: 'sniff' }, { protocol: 'dns', action: 'hijack-dns' }, { ip_cidr: [wg.dnsServer + '/32'], outbound: 'warp' }, { ip_is_private: true, outbound: 'direct' }],
    },
    experimental: { clash_api: { external_controller: `127.0.0.1:${CLASH_PORT}` } },
  };
}
module.exports = { CLASH_PORT, COUNTRIES, WARP_TRIES, genKeys, parseConf, warpToWg, buildConfig };
