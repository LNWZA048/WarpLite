const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const { spawn, execFile } = require('child_process');
const core = require('./core');

const IS_WIN = process.platform === 'win32';
const MOCK = process.env.WARP_MOCK === '1'; // ใช้ทดสอบ UI นอก Windows เท่านั้น
const API = process.env.WARP_API || 'https://api.cloudflareclient.com/v0a1922';
const TASK = 'WarpLite';
const HDR = { 'User-Agent': 'okhttp/3.12.1', 'CF-Client-Version': 'a-6.3-1922', 'Content-Type': 'application/json' };
const DEFAULTS = { mode: 'warp', country: 'auto', unlock: false };

let win, proc, trafficReq, stopping = false, busy = false, mockTimer;
let store = { settings: { ...DEFAULTS }, account: null, dnsBackup: null, unlockBackup: null };
let state = { status: 'off', via: '', country: '', ip: '', endpoint: '', notice: '', error: '', unlockApplied: false, admin: true };

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const dataFile = () => path.join(app.getPath('userData'), 'state.json');
const countriesDir = () => path.join(app.getPath('userData'), 'countries');
const load = () => { try { const j = JSON.parse(fs.readFileSync(dataFile(), 'utf8')); store = { ...store, ...j, settings: { ...DEFAULTS, ...(j.settings || {}), unlock: false } }; } catch {} };
const save = () => { try { fs.mkdirSync(path.dirname(dataFile()), { recursive: true }); fs.writeFileSync(dataFile(), JSON.stringify(store)); } catch {} };
const send = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };
const setState = (p) => { state = { ...state, ...p }; send('state', state); };
const exe = () => process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
const enginePath = () => (app.isPackaged ? path.join(process.resourcesPath, 'engine', 'sing-box.exe') : path.join(__dirname, '..', 'engine', 'sing-box.exe'));
const regionName = (c) => { try { return new Intl.DisplayNames(['en'], { type: 'region' }).of(c === 'UK' ? 'GB' : c) || c; } catch { return c; } };

function ps(script, timeout = 25000) {
  return new Promise((res, rej) => execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { windowsHide: true, timeout }, (e, out, err) => (e ? rej(new Error((err || e.message).trim())) : res(out))));
}

/* ---------- admin: อนุมัติครั้งเดียว แล้วใช้ Scheduled Task เปิดแบบ admin ต่อไป ---------- */
const isAdmin = () => new Promise((r) => execFile('fsutil', ['dirty', 'query', process.env.SystemDrive || 'C:'], { windowsHide: true }, (e) => r(!e)));
async function taskMatches() {
  try { const o = await ps(`(Get-ScheduledTask -TaskName '${TASK}' -ErrorAction Stop).Actions.Execute`); return o.trim().toLowerCase() === exe().toLowerCase(); } catch { return false; }
}
async function ensureTask() {
  if (await taskMatches()) return;
  const p = exe().replace(/'/g, "''");
  await ps(`$a=New-ScheduledTaskAction -Execute '${p}'; $pr=New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Highest; $s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew; Register-ScheduledTask -TaskName '${TASK}' -Action $a -Principal $pr -Settings $s -Force | Out-Null`);
}
// คืนค่า true = โปรเซสนี้ทำงานต่อได้ (เป็น admin แล้ว)
async function elevate() {
  if (!IS_WIN || MOCK) return true;
  if (await isAdmin()) { try { await ensureTask(); } catch {} return true; }
  if (await taskMatches()) { execFile('schtasks', ['/run', '/tn', TASK], { windowsHide: true }, () => {}); return false; }
  execFile('powershell.exe', ['-NoProfile', '-Command', `Start-Process -FilePath '${exe().replace(/'/g, "''")}' -Verb RunAs`], { windowsHide: true }, () => {});
  return false;
}

/* ---------- WARP account ---------- */
async function register() {
  const kp = core.genKeys();
  const r = await fetch(`${API}/reg`, {
    method: 'POST', headers: HDR, signal: AbortSignal.timeout(15000),
    body: JSON.stringify({ install_id: '', fcm_token: '', tos: new Date().toISOString(), key: kp.pub, type: 'Android', model: 'PC', locale: 'en_US' }),
  }).catch((e) => { throw new Error('Cannot reach Cloudflare (' + (e.cause?.code || e.message) + ')'); });
  if (!r.ok) throw new Error('WARP registration failed (HTTP ' + r.status + ')');
  const j = await r.json();
  fetch(`${API}/reg/${j.id}`, { method: 'PATCH', headers: { ...HDR, Authorization: 'Bearer ' + j.token }, body: JSON.stringify({ warp_enabled: true }), signal: AbortSignal.timeout(10000) }).catch(() => {});
  const c = j.config; let reserved = [0, 0, 0];
  try { if (c.client_id) reserved = Array.from(Buffer.from(c.client_id, 'base64')).slice(0, 3); } catch {}
  return { id: j.id, token: j.token, private_key: kp.priv, address4: c.interface.addresses.v4, address6: c.interface.addresses.v6, peer_public_key: c.peers[0].public_key, reserved };
}
async function ensureAccount() { if (!store.account) { store.account = await register(); save(); } return store.account; }

/* ---------- engine ---------- */
let logTail = [];
function startEngine(cfg) {
  const dir = path.join(app.getPath('userData'), 'engine-work');
  fs.mkdirSync(dir, { recursive: true });
  const cfgPath = path.join(dir, 'config.json');
  fs.writeFileSync(cfgPath, JSON.stringify(cfg));
  logTail = [];
  proc = spawn(enginePath(), ['run', '-c', cfgPath, '-D', dir], { windowsHide: true });
  const onLog = (b) => { logTail.push(...b.toString().split(/\r?\n/).filter(Boolean)); logTail = logTail.slice(-15); };
  proc.stdout.on('data', onLog); proc.stderr.on('data', onLog);
  proc.on('exit', () => {
    const was = stopping; proc = null;
    if (!was && state.status === 'on') { stopTraffic(); setState({ status: 'error', error: 'Connection lost. ' + (logTail.slice(-1)[0] || ''), ip: '', country: '', via: '' }); }
  });
}
async function killEngine() {
  stopTraffic();
  if (!proc) return;
  const p = proc; stopping = true;
  await new Promise((res) => {
    p.once('exit', res);
    if (IS_WIN) execFile('taskkill', ['/PID', String(p.pid), '/T', '/F'], { windowsHide: true }, () => {}); else p.kill('SIGKILL');
    setTimeout(res, 4000);
  });
  proc = null; stopping = false;
}
async function waitReady() {
  for (let i = 0; i < 25; i++) {
    if (!proc) throw new Error(logTail.slice(-2).join(' ') || 'Engine stopped');
    const ok = await new Promise((res) => {
      const r = http.get({ host: '127.0.0.1', port: core.CLASH_PORT, path: '/version', timeout: 800 }, (x) => { x.resume(); res(x.statusCode === 200); });
      r.on('error', () => res(false)); r.on('timeout', () => { r.destroy(); res(false); });
    });
    if (ok) return;
    await sleep(400);
  }
  throw new Error('Engine did not start. ' + logTail.slice(-2).join(' '));
}
async function trace() {
  const r = await fetch('https://www.cloudflare.com/cdn-cgi/trace', { signal: AbortSignal.timeout(7000), cache: 'no-store' });
  const t = Object.fromEntries((await r.text()).split('\n').filter(Boolean).map((l) => l.split('=')));
  return { ip: t.ip || '', loc: t.loc || '', warp: t.warp || 'off' };
}
function watchTraffic() {
  stopTraffic();
  trafficReq = http.get({ host: '127.0.0.1', port: core.CLASH_PORT, path: '/traffic' }, (res) => {
    let buf = '';
    res.on('data', (c) => {
      buf += c; let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); try { const t = JSON.parse(line); send('speed', { up: t.up, down: t.down }); } catch {} }
    });
  });
  trafficReq.on('error', () => {});
}
function stopTraffic() { try { trafficReq && trafficReq.destroy(); } catch {} trafficReq = null; clearInterval(mockTimer); }

// เปิดอุโมงค์หนึ่งครั้ง: สำเร็จคืนข้อมูล trace, ล้มเหลวโยน error (และปิดเอนจิน)
async function tryTunnel(wg, needWarp) {
  try {
    startEngine(core.buildConfig(wg, store.settings.unlock));
    await waitReady(); await sleep(1500);
    let last = 'Connection test failed';
    for (let i = 0; i < 3; i++) {
      try { const t = await trace(); if (!needWarp || t.warp === 'on' || t.warp === 'plus') { watchTraffic(); return t; } last = 'Not routed through WARP'; } catch { last = 'Connection test failed'; }
      await sleep(1000);
    }
    throw new Error(last);
  } catch (e) { await killEngine(); throw e; }
}

/* ---------- DNS only ---------- */
const DNS_SERVERS = ['1.1.1.1', '1.0.0.1'];
async function dnsApply() {
  if (!store.dnsBackup) {
    const out = await ps("Get-DnsClientServerAddress -AddressFamily IPv4 | Select-Object InterfaceIndex,@{n='S';e={@($_.ServerAddresses)}} | ConvertTo-Json -Compress");
    const j = JSON.parse(out || '[]'); store.dnsBackup = Array.isArray(j) ? j : [j]; save();
  }
  const s = DNS_SERVERS.map((x) => `'${x}'`).join(',');
  await ps(`Get-NetAdapter | Where-Object Status -eq 'Up' | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ServerAddresses (${s}) }; Clear-DnsClientCache`);
}
async function dnsRestore() {
  if (!store.dnsBackup) return;
  const lines = store.dnsBackup.map((a) => {
    const s = (a.S || []).map((x) => `'${x}'`).join(',');
    return s ? `Set-DnsClientServerAddress -InterfaceIndex ${a.InterfaceIndex} -ServerAddresses (${s}) -ErrorAction SilentlyContinue` : `Set-DnsClientServerAddress -InterfaceIndex ${a.InterfaceIndex} -ResetServerAddresses -ErrorAction SilentlyContinue`;
  });
  try { await ps(lines.join('; ') + '; Clear-DnsClientCache'); store.dnsBackup = null; save(); } catch {}
}

/* ---------- unlock network speed (ปรับ TCP/QoS + MTU/DNS, คืนค่าตอนปิด) ---------- */
const REGS = [
  { path: 'HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\Psched', name: 'NonBestEffortLimit', value: 0 },
  { path: 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile', name: 'NetworkThrottlingIndex', value: 4294967295 },
];
async function unlockOn() {
  if (!store.unlockBackup) {
    const get = REGS.map((r, i) => `$o.r${i}=(Get-ItemProperty -Path '${r.path}' -Name '${r.name}' -ErrorAction SilentlyContinue).'${r.name}'`).join('; ');
    const out = await ps(`$o=@{}; ${get}; try{$t=Get-NetTCPSetting -SettingName Internet; $o.auto=[string]$t.AutoTuningLevelLocal; $o.heur=[string]$t.ScalingHeuristics}catch{}; $o | ConvertTo-Json -Compress`);
    store.unlockBackup = JSON.parse(out || '{}'); save();
  }
  const set = REGS.map((r) => `try{ if(-not (Test-Path '${r.path}')){New-Item -Path '${r.path}' -Force | Out-Null}; Set-ItemProperty -Path '${r.path}' -Name '${r.name}' -Value ${r.value} -Type DWord -Force }catch{}`).join('; ');
  await ps(`${set}; try{Set-NetTCPSetting -SettingName Internet -AutoTuningLevelLocal Normal -ScalingHeuristics Disabled}catch{}; Clear-DnsClientCache`);
}
async function unlockOff() {
  const b = store.unlockBackup; if (!b) return;
  const rs = REGS.map((r, i) => (b['r' + i] == null ? `try{Remove-ItemProperty -Path '${r.path}' -Name '${r.name}' -ErrorAction SilentlyContinue}catch{}` : `try{Set-ItemProperty -Path '${r.path}' -Name '${r.name}' -Value ${Number(b['r' + i])} -Type DWord -Force}catch{}`)).join('; ');
  const tcp = b.auto ? `try{Set-NetTCPSetting -SettingName Internet -AutoTuningLevelLocal ${b.auto} -ScalingHeuristics ${b.heur || 'Default'}}catch{}` : '';
  try { await ps(`${rs}; ${tcp}`); store.unlockBackup = null; save(); } catch {}
}

/* ---------- connect / disconnect ---------- */
function countryFile(code) {
  const names = code === 'UK' ? ['UK', 'GB'] : [code];
  try {
    const files = fs.readdirSync(countriesDir());
    for (const n of names) { const f = files.find((x) => x.toLowerCase() === n.toLowerCase() + '.conf'); if (f) return path.join(countriesDir(), f); }
  } catch {}
  return null;
}
const countryList = () => core.COUNTRIES.map((c) => ({ ...c, hasFile: c.code === 'auto' ? true : !!countryFile(c.code) }));

async function connect() {
  if (busy || state.status === 'on') return;
  busy = true; const s = store.settings;
  setState({ status: 'connecting', error: '', notice: '', via: '', country: '', ip: '', endpoint: '' });
  try {
    if (MOCK) {
      await sleep(1200);
      const miss = s.country !== 'auto' && !countryFile(s.country);
      setState({ status: 'on', via: s.mode === 'dns' ? 'dns' : 'warp', country: s.mode === 'dns' ? '' : 'Thailand', ip: '203.0.113.7', endpoint: '162.159.192.1:2408', notice: miss && s.mode !== 'dns' ? `No ${s.country}.conf found. Connected through WARP instead.` : '' });
      mockTimer = setInterval(() => send('speed', { up: 230000 + Math.random() * 90000, down: 2400000 + Math.random() * 600000 }), 1000);
      return;
    }
    if (!IS_WIN) throw new Error('Windows only');
    if (!state.admin) throw new Error('Administrator rights are required');
    if (s.mode === 'dns') { await dnsApply(); setState({ status: 'on', via: 'dns', endpoint: DNS_SERVERS.join(' / ') }); return; }

    let notice = '';
    if (s.country !== 'auto') {
      const cname = core.COUNTRIES.find((c) => c.code === s.country).name, f = countryFile(s.country);
      if (!f) notice = `No ${s.country}.conf found for ${cname}. Connected through WARP instead.`;
      else {
        try {
          const wg = core.parseConf(fs.readFileSync(f, 'utf8'));
          setState({ endpoint: `${wg.peer.address}:${wg.peer.port}` });
          const t = await tryTunnel(wg, false);
          setState({ status: 'on', via: 'file', country: t.loc ? regionName(t.loc) : cname, ip: t.ip, endpoint: `${wg.peer.address}:${wg.peer.port}`, notice: '' });
          return;
        } catch (e) { notice = `Could not connect to ${cname} (${e.message}). Connected through WARP instead.`; }
      }
    }
    const acc = await ensureAccount();
    let lastErr = 'No WARP endpoint reachable';
    for (const [ip, port] of core.WARP_TRIES) {
      setState({ endpoint: `${ip}:${port}` });
      try {
        const t = await tryTunnel(core.warpToWg(acc, ip, port), true);
        setState({ status: 'on', via: 'warp', country: t.loc ? regionName(t.loc) : '', ip: t.ip, endpoint: `${ip}:${port}`, notice });
        return;
      } catch (e) { lastErr = e.message; }
    }
    throw new Error(lastErr);
  } catch (e) {
    await killEngine();
    setState({ status: 'error', error: e.message, ip: '', country: '', via: '' });
  } finally { busy = false; }
}
async function disconnect() {
  if (busy) return; busy = true;
  try { clearInterval(mockTimer); await killEngine(); await dnsRestore(); } finally { busy = false; }
  setState({ status: 'off', error: '', notice: '', via: '', ip: '', country: '', endpoint: '' });
  send('speed', { up: 0, down: 0 });
}
async function setUnlock(on) {
  store.settings.unlock = on; save();
  if (IS_WIN && !MOCK) { try { on ? await unlockOn() : await unlockOff(); } catch {} }
  setState({ unlockApplied: on });
  if (state.status === 'on' && state.via !== 'dns') { await disconnect(); connect(); }
}

ipcMain.handle('init', () => ({ state, settings: store.settings, countries: countryList() }));
ipcMain.handle('toggle', () => (state.status === 'on' ? disconnect() : state.status === 'connecting' ? null : connect()));
ipcMain.handle('set', async (_e, p) => {
  if ('unlock' in p) { await setUnlock(!!p.unlock); return store.settings; }
  store.settings = { ...store.settings, ...p }; save();
  if (state.status === 'on') { await disconnect(); connect(); }
  return store.settings;
});
ipcMain.handle('folder', async () => { fs.mkdirSync(countriesDir(), { recursive: true }); const r = path.join(countriesDir(), 'README.txt'); if (!fs.existsSync(r)) fs.writeFileSync(r, 'Put WireGuard config files here, named by country:\r\nSG.conf  JP.conf  US.conf  UK.conf  MY.conf\r\nRestart the app after adding files.\r\n'); await shell.openPath(countriesDir()); });

/* ---------- window / lifecycle ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 800, height: 470, minWidth: 740, minHeight: 440, title: 'WarpLite', autoHideMenuBar: true, backgroundColor: '#ffffff',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false },
  });
  win.setMenu(null);
  win.loadFile(path.join(__dirname, 'index.html'));
}
async function cleanup() { try { await killEngine(); } catch {} try { await unlockOff(); } catch {} try { await dnsRestore(); } catch {} }

app.whenReady().then(async () => {
  if (!(await elevate())) return app.exit(0);
  if (!app.requestSingleInstanceLock()) return app.exit(0);
  app.on('second-instance', () => { if (win) { win.show(); win.focus(); } });
  load();
  if (IS_WIN && !MOCK) { state.admin = true; await dnsRestore(); await unlockOff(); } // เก็บกวาดกรณีปิดผิดปกติรอบก่อน
  createWindow();
});
app.on('before-quit', async (e) => { if (app.isQuitting) return; e.preventDefault(); app.isQuitting = true; await cleanup(); app.exit(0); });
app.on('window-all-closed', () => app.quit());
