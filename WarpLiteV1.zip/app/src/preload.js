const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('warp', {
  init: () => ipcRenderer.invoke('init'),
  toggle: () => ipcRenderer.invoke('toggle'),
  set: (p) => ipcRenderer.invoke('set', p),
  folder: () => ipcRenderer.invoke('folder'),
  onState: (f) => ipcRenderer.on('state', (_e, d) => f(d)),
  onSpeed: (f) => ipcRenderer.on('speed', (_e, d) => f(d)),
});
